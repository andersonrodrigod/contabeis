const { Sequelize } = require('sequelize')

require('dotenv').config(); // Carrega as variáveis de ambiente do arquivo .env

const sequelize = new Sequelize(process.env.DB_DATABASE, process.env.DB_USER, process.env.DB_PASSWORD, {
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  dialect: 'mysql',
});

try {
    sequelize.authenticate()
    console.log('Conectamos ao banco de dados')
} catch(err) {
    console.log(err)
}

module.exports = sequelize